﻿using System;
using System.Windows.Forms;
using ToDoListProcess.Business;
using ToDoListProcess.Common;
using ToDoListProcess.DL;

namespace TodoList
{
    public partial class Dashboard : Form
    {
        private readonly ITaskData taskData = new DbTaskData();
        private readonly DbUserManager userManager = new DbUserManager();
        private readonly ToDoListManager toDoList;
        private readonly string currentUser;

        public Dashboard(string username)
        {
            InitializeComponent();
            currentUser = username;
            toDoList = new ToDoListManager(taskData);
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            LoadTasks();
        }

        private void LoadTasks()
        {
            listBox1.Items.Clear();
            var tasks = toDoList.GetTasks(currentUser);
            foreach (var task in tasks)
            {
                listBox1.Items.Add(task);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string input = Microsoft.VisualBasic.Interaction.InputBox("Enter task description:", "Add Task", "");
            if (!string.IsNullOrWhiteSpace(input))
            {
                string result = toDoList.AddTask(currentUser, input);
                MessageBox.Show(result == "success" ? "Task added!" : result);
                LoadTasks();
            }
            else
            {
                MessageBox.Show("Task description cannot be empty.");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                string current = listBox1.SelectedItem.ToString();
                string newDesc = Microsoft.VisualBasic.Interaction.InputBox("Edit task:", "Edit Task", current);
                if (!string.IsNullOrWhiteSpace(newDesc))
                {
                    string result = toDoList.EditTask(listBox1.SelectedIndex, newDesc, currentUser);
                    MessageBox.Show(result == "success" ? "Task updated." : result);
                    LoadTasks();
                }
            }
            else
            {
                MessageBox.Show("Please select a task to edit.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                var confirm = MessageBox.Show("Are you sure you want to delete this task?", "Confirm Delete", MessageBoxButtons.YesNo);
                if (confirm == DialogResult.Yes)
                {
                    string result = toDoList.DeleteTask(listBox1.SelectedIndex, currentUser);
                    MessageBox.Show(result == "success" ? "Task deleted." : result);
                    LoadTasks();
                }
            }
            else
            {
                MessageBox.Show("Please select a task to delete.");
            }
        }

        private void btnMark_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                string result = toDoList.MarkAsDone(listBox1.SelectedIndex, currentUser);
                MessageBox.Show(result == "success" ? "Task marked as done." : result);
                LoadTasks();
            }
            else
            {
                MessageBox.Show("Please select a task to mark as done.");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = Microsoft.VisualBasic.Interaction.InputBox("Enter keyword to search:", "Search Tasks", "");
            if (!string.IsNullOrWhiteSpace(keyword))
            {
                var results = toDoList.SearchTasks(keyword, currentUser);
                listBox1.Items.Clear();
                foreach (var task in results)
                {
                    listBox1.Items.Add(task);
                }

                if (results.Count == 0)
                {
                    MessageBox.Show("No tasks found.");
                }
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Logged out successfully.");
            Application.Exit(); // Or show login form again
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                string selectedTask = listBox1.SelectedItem.ToString();
                MessageBox.Show("Selected Task:\n" + selectedTask);
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Optional search box logic
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            // Optional live search
        }
    }
}


