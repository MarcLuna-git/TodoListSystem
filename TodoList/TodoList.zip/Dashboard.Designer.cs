﻿namespace TodoList
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ListBox listBox1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            listBox1 = new ListBox();
            label1 = new Label();
            btnAdd = new Button();
            btnEdit = new Button();
            btnDelete = new Button();
            btnMark = new Button();
            btnSearch = new Button();
            btnLogout = new Button();
            tbSearch = new TextBox();
            tbAddTask = new TextBox();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.Font = new Font("Stencil", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 24;
            listBox1.Location = new Point(74, 229);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(300, 388);
            listBox1.TabIndex = 0;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.RosyBrown;
            label1.Font = new Font("Stencil", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(365, 22);
            label1.Name = "label1";
            label1.RightToLeft = RightToLeft.No;
            label1.Size = new Size(522, 47);
            label1.TabIndex = 2;
            label1.Text = "WELCOME TO DASHBOARD";
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.LightCoral;
            btnAdd.Font = new Font("Stencil", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(665, 229);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(151, 40);
            btnAdd.TabIndex = 10;
            btnAdd.Text = "ADD TASK";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.LightCoral;
            btnEdit.Font = new Font("Stencil", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEdit.ForeColor = Color.White;
            btnEdit.Location = new Point(433, 229);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(151, 40);
            btnEdit.TabIndex = 11;
            btnEdit.Text = "EDIT TASK";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.LightCoral;
            btnDelete.Font = new Font("Stencil", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(433, 301);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(151, 40);
            btnDelete.TabIndex = 12;
            btnDelete.Text = "DELETE TASK";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnMark
            // 
            btnMark.BackColor = Color.LightCoral;
            btnMark.Font = new Font("Stencil", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnMark.ForeColor = Color.White;
            btnMark.Location = new Point(433, 377);
            btnMark.Name = "btnMark";
            btnMark.Size = new Size(151, 40);
            btnMark.TabIndex = 13;
            btnMark.Text = "MARK AS DONE";
            btnMark.UseVisualStyleBackColor = false;
            btnMark.Click += btnMark_Click;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.LightCoral;
            btnSearch.Font = new Font("Stencil", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSearch.ForeColor = Color.White;
            btnSearch.Location = new Point(47, 101);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(151, 40);
            btnSearch.TabIndex = 14;
            btnSearch.Text = "SEARCH";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnLogout
            // 
            btnLogout.BackColor = Color.LightCoral;
            btnLogout.Font = new Font("Stencil", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLogout.ForeColor = Color.White;
            btnLogout.Location = new Point(1019, 32);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(151, 40);
            btnLogout.TabIndex = 15;
            btnLogout.Text = "LOGOUT";
            btnLogout.UseVisualStyleBackColor = false;
            // 
            // tbSearch
            // 
            tbSearch.Location = new Point(213, 108);
            tbSearch.Name = "tbSearch";
            tbSearch.Size = new Size(215, 27);
            tbSearch.TabIndex = 16;
            tbSearch.TextChanged += tbSearch_TextChanged;
            // 
            // tbAddTask
            // 
            tbAddTask.Location = new Point(841, 236);
            tbAddTask.Name = "tbAddTask";
            tbAddTask.Size = new Size(215, 27);
            tbAddTask.TabIndex = 18;
            tbAddTask.TextChanged += textBox1_TextChanged;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1220, 725);
            Controls.Add(listBox1);
            Controls.Add(tbAddTask);
            Controls.Add(tbSearch);
            Controls.Add(btnLogout);
            Controls.Add(btnSearch);
            Controls.Add(btnMark);
            Controls.Add(btnDelete);
            Controls.Add(btnEdit);
            Controls.Add(btnAdd);
            Controls.Add(label1);
            Name = "Dashboard";
            Text = "Dashboard";
            Load += Dashboard_Load;
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private Label label1;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private Button btnMark;
        private Button btnSearch;
        private Button btnLogout;
        private TextBox tbSearch;
        private TextBox tbAddTask;
    }
}